import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Date;


public class canvas extends JPanel{
    View myView;
    ArrayList<drawings> shape;
    int index = 0;
    Color color = Color.RED;
    boolean playBack = false;
    boolean playForward = false;
    public canvas(View v) {
        myView = v;
        shape = v.graphs;
        //pb = myView.playbar;
        //tmp = pb.tmp;
        if (index == 5000) index = 0;
        this.setSize(new Dimension(670, 500));
        this.setBackground(Color.WHITE);
        this.setOpaque(true);
        //this.setBorder(new LineBorder(Color.darkGray, 2));
        this.addMouseListener(new MouseAdapter(){
            public void mousePressed(MouseEvent e) {
                if (index == shape.size()) {
                    shape.add(new drawings());
                }
                else {
                    shape.get(index).clearPoints();
                }
                // change shape type
//                shape.setIsClosed(true);
//                shape.setIsFilled(true);
                shape.get(index).setColour(color);
                // try setting scale to something other than 1
                shape.get(index).setScale(1.0f);
                index++;
                System.out.print(index);
                repaint();
            }
        });
        this.addMouseMotionListener(new MouseAdapter(){
            public void mouseDragged(MouseEvent e) {
                while (index < shape.size()) {
                    shape.remove(shape.size() - 1);
                }
                shape.get(index-1).white = false;
                shape.get(index-1).addPoint(e.getX(), e.getY());
                repaint();
                myView.notifyScroll(index);
            }
        });
    }
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g; // cast to get 2D drawing methods
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,  // antialiasing look nicer
                RenderingHints.VALUE_ANTIALIAS_ON);
        if (shape != null) {
            for (int i = 0; i < shape.size(); i++) {
                //System.out.print(index + " ");
                shape.get(i).draw(g2);
            }
        }
        //g.drawImage(g2, 0,0,null);
    }
    public void colorChange(Color c) {
        this.color = c;
    }

    public void goBackward () {
        if (index > 0) {
            drawings current = shape.get(index - 1);
            current.setColour(Color.WHITE);
            repaint();
            index--;
            System.out.print("GoBackward: " + index);
            myView.notifyScroll(index);
        }
    }

    public void goForward () {
        if (index < shape.size()) {
            //System.out.print(index);
            index++;
            shape.get(index-1).white = false;
            repaint();
            myView.notifyScroll(index);
        }
    }

    public void playBack() {
        playBack = true;
        Timer timer = new Timer();

        int interval = 1000; // One second

        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (index > 0 && playBack) {
                    drawings current = shape.get(index - 1);
                    int size = current.points.size();
                    for (int i=0; i < current.points.size(); i++) {
                        current.xpoints[i] = (int)current.points.get(size-i-1).x;
                        current.ypoints[i] = (int)current.points.get(size-i-1).y;
                    }
                    current.setColour(Color.WHITE);
                    repaint();
                    index--;
                    myView.notifyScroll(index);
                }
                else {
                    //System.out.print(index);
                    playBack = false;
                    index = 0;
                    timer.cancel();
                    timer.purge();
                }
            }
        }, new Date(),interval);
    }

    public void playForward () {
        playForward = true;
        Timer timer = new Timer();

        int interval = 1000; // One second

        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (index < shape.size() && playForward) {
                    index++;
                    System.out.print("playForward:  " + index);
                    drawings current = shape.get(index - 1);
                    for (int i=0; i < current.points.size(); i++) {
                        current.xpoints[i] = (int)current.points.get(i).x;
                        current.ypoints[i] = (int)current.points.get(i).y;
                    }
                    current.white = false;
                    current.setColour(current.colour);
                    repaint();
                    myView.notifyScroll(index);
                    //System.out.print(index + " ");
                }
                else {
                    playForward = false;
                    index = shape.size();
                    timer.cancel();
                    timer.purge();
                }
            }
        }, new Date(),interval);
    }
    public void sliderBack() {
        shape.get(index - 1).white = true;
        index--;
        //System.out.print(index);
        repaint();
    }

    public void sliderForward() {
        index++;
        shape.get(index - 1).white = false;
        //System.out.print(index);
        repaint();
    }
}

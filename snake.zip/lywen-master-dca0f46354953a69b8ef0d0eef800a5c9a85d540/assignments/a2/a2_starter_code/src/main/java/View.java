
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

public class View extends JFrame implements Observer {

    private Model model;
    ColorBar cb;
    canvas cv;
    public playback playbar;
    public ArrayList<drawings> graphs = new ArrayList<drawings>();
    private static JFileChooser fileChooser;
    /**
     * Create a new View.
     */
    public View(Model model) throws IOException {
        // Set up the window.
        this.setTitle("Drawing");
        this.setMinimumSize(new Dimension(400, 300));
        this.setSize(800, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Hook up this observer so that it will be notified when the model
        // changes.
        this.model = model;
        model.addObserver(this);

        // set border layout
        this.setLayout(new GridBagLayout());
        // initial colorbar

        manageLayout();
        setMenu();

        resizeVersion();
        setVisible(true);
    }

    // set canvas
    public void manageLayout () throws IOException {
        // set canvas
        cv = new canvas(this);
        JScrollPane cvScroll = new JScrollPane(cv);
        cvScroll.setSize(new Dimension(670, 500));
        cvScroll.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        cvScroll.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        //set color bar
        cb = new ColorBar(this);

        // set bottom tool bar
        playbar = new playback(this);
        JScrollPane toolScroll = new JScrollPane(playbar);
        toolScroll.setSize(new Dimension(750, 100));
        toolScroll.setHorizontalScrollBarPolicy(
                JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        toolScroll.setVerticalScrollBarPolicy(
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        Box b = Box.createHorizontalBox();
        b.add(Box.createHorizontalStrut(5));
        b.add(cb);
        b.add(Box.createHorizontalStrut(5));
        b.add(cvScroll);
        GridBagConstraints c1 = new GridBagConstraints();
        c1.gridx = 0;
        c1.gridy = 0;
        c1.weightx = 1.0;
        c1.weighty = 1.0;
        c1.fill = GridBagConstraints.BOTH ;
        b.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                super.componentResized(e);
                Rectangle component = e.getComponent().getBounds();
                //cv.clearCanvas();
                e.getComponent().setBounds(component.x, component.y, component.width, component.height);
                cb.onResize();
                //cv.clearCanvas();
                //cv.resizeManage();
                //System.out.print(cv.getWidth() + " ");
            }
        });

        this.add(b, c1);

        GridBagConstraints c2 = new GridBagConstraints();
        c2.gridx = 0;
        c2.gridy = 1;
        c2.weightx = 1.0;
        c2.weighty = 0.5;
        c2.fill = GridBagConstraints.BOTH ;
        // 加入 middlePanel
        this.add(toolScroll,c2);
    }

    //setting menues
    public void setMenu () {
        JMenuBar menu = new JMenuBar();
        JMenu File = new JMenu("File");
        JMenuItem save = new JMenuItem("Save");
        JMenuItem open = new JMenuItem("Open");
        JMenuItem newFile = new JMenuItem("New");
        JMenuItem close = new JMenuItem("Close");

        View tmp = this;
        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.lines = graphs;
                model.saveFile(tmp, fileChooser);
            }
        });

        open.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.openFile(tmp, fileChooser);
            }
        });

        JFrame tmpFrame = this;
        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispatchEvent(new WindowEvent(tmpFrame, WindowEvent.WINDOW_CLOSING));
            }
        });

        newFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int i = JOptionPane.showConfirmDialog(tmp, "Do you want to save the file?");
                if (i == JOptionPane.YES_OPTION) {
                    model.saveFile(tmp, fileChooser);
                }
                graphs = new ArrayList<drawings>();
                model.lines = graphs;
                cv.shape = graphs;
                playbar.lines = graphs;
                cv.index = 0;
                repaint();
            }
        });

        File.add(save);
        File.add(open);
        File.add(newFile);
        File.add(close);
        menu.add(File);
        this.setJMenuBar(menu);
    }

    //Deal with resizing
    public void resizeVersion () {
        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                super.componentResized(e);
                int minWidth = 800;
                int minHeight = 600;

                Rectangle component = e.getComponent().getBounds();
                //cv.clearCanvas();
                e.getComponent().setBounds(component.x, component.y, component.width, component.width*minHeight/minWidth);
                //cv.resizeManage();
            }
        });
    }


    /**
     * Update with data from the model.
     */
    public void update(Object observable) {
        // XXX Fill this in with the logic for updating the view when the model
        // changes.
        System.out.println("Model changed!");
        graphs = model.lines;
        cv.shape = graphs;
        playbar.lines = graphs;
        cv.index = graphs.size();
        repaint();
    }
    // change notyfying methods
    public void notifyColorChange (Color c) {
        cb.colorChange(c);
        cv.colorChange(c);
    }

    public void notifyGoBack() {
        cv.goBackward();
    }

    public void notifyGoForward() {
        cv.goForward();
    }

    public void notifyplayBack() {
        cv.playBack();
    }

    public void notifyplayForward () {
        cv.playForward();
    }

    public void notifySliderWipe () {
        cv.sliderBack();
    }

    public void notifySliderAppear() {
        cv.sliderForward();
    }

    public void notifyScroll (int index) {
        playbar.ScrollValue (index);
    }

}

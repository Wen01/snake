import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.vecmath.*;


public class playback extends JPanel {
    View myView;
    ArrayList<drawings> lines;
    int index;
    int preValue = 100;
    JSlider scrollbar;
    boolean changeActive = true;
    public playback (View v) throws IOException {
        myView = v;
        lines = myView.graphs;
        index = lines.size();
        this.setPreferredSize(new Dimension(750, 70));
        this.setBackground(Color.WHITE);
        this.setBorder(new LineBorder(Color.darkGray, 2));

        scrollbar = scrollbar();
        JButton playButton = playButton();

        JButton playback = playBack();

        JButton arrowforward = arrowForward();

        JButton arrowback = arrowBackward();

        Box b = Box.createHorizontalBox();
        b.add(scrollbar);
        //b.add(Box.createHorizontalStrut(5));
        b.add(playback);
        //b.add(Box.createHorizontalStrut(5));
        b.add(arrowback);
        //b.add(Box.createHorizontalStrut(5));
        b.add(arrowforward);
        //b.add(Box.createHorizontalStrut(5));
        b.add(playButton);
        this.add(b);
    }


    private JSlider scrollbar() {
        JSlider slider = new JSlider(0, 100, 100);
        slider.setPreferredSize(new Dimension (550, 50));
        slider.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                int size = lines.size();
                int range = 100 / size;
                if (preValue - slider.getValue() >= range / 2 && changeActive) {
                    myView.notifySliderWipe();
                    preValue = slider.getValue() - range/2;
                    //System.out.print(preValue);
                }
                else if (slider.getValue() - preValue >= range / 2 && changeActive) {
                    myView.notifySliderAppear();
                    preValue = slider.getValue() + range/2;
                }
            }
        });
        return slider;
    }

    private JButton playButton () throws IOException {
        JButton playButton = new JButton();
        playButton.setSize(new Dimension (50, 50));
        Image img = ImageIO.read(this.getClass().getResource("images.png"));
        Image dimg = img.getScaledInstance(45, 50, Image.SCALE_SMOOTH);
        playButton.setIcon(new ImageIcon(dimg));
        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                myView.notifyplayForward();
            }
        });

        return playButton;
    }

    private JButton playBack () throws IOException {
        JButton playBack = new JButton();
        playBack.setSize(new Dimension (50, 50));
        Image img2 = ImageIO.read(this.getClass().getResource("images2.png"));
        Image dimg2 = img2.getScaledInstance(45, 50, Image.SCALE_SMOOTH);
        playBack.setIcon(new ImageIcon(dimg2));
        playBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                myView.notifyplayBack();
            }
        });

        return playBack;
    }

    private JButton arrowForward () throws IOException {
        JButton button = new JButton();
        button.setSize(new Dimension (50, 50));
        Image img = ImageIO.read(this.getClass().getResource("arrow1.png"));
        Image dimg = img.getScaledInstance(45, 50, Image.SCALE_SMOOTH);
        button.setIcon(new ImageIcon(dimg));
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                myView.notifyGoForward();
            }
        });
        return button;
    }

    private JButton arrowBackward () throws IOException {
        JButton button = new JButton();
        button.setSize(new Dimension (50, 50));
        Image img = ImageIO.read(this.getClass().getResource("arrow2.png"));
        Image dimg = img.getScaledInstance(45, 50, Image.SCALE_SMOOTH);
        button.setIcon(new ImageIcon(dimg));
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                myView.notifyGoBack();
            }
        });
        return button;
    }

    public void ScrollValue (int index) {
        changeActive = false;
        int range = 100 / lines.size();
        scrollbar.setValue(index * range);
        preValue = index * range;
        changeActive = true;
    }

}

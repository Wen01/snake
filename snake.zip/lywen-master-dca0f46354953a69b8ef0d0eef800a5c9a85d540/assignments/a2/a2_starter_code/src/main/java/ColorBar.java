import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.BorderFactory;
import javax.swing.border.Border;

public class ColorBar extends Box {
    private colorPalette cp ;
    private colorSelection cs;
    private View myView;

    public ColorBar (View v) {
        super(BoxLayout.Y_AXIS);
        this.setPreferredSize(new Dimension(120,500));
        // create a palete
        cp = new colorPalette(v);
        Box box = new Box(BoxLayout.X_AXIS);
        box.add(cp);
        this.add(box);

        // create color selection label
        cs = new colorSelection();
        Border border = BorderFactory.createLineBorder(Color.lightGray, 2);
        cs.setBorder(border);
        cs.setAlignmentX(0.5f);
        this.add(cs);
        this.setBackground(Color.WHITE);

    }

    public void colorChange (Color c) {
        cs.changeColor(c);
    }

    public void onResize () {
        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                    super.componentResized(e);
                    //int minWidth = 500;
                    //int minHeight = 350;
                    Rectangle component = e.getComponent().getBounds();
                    e.getComponent().setBounds(component.x, component.y, component.width, component.height);

            }
        });
    }

}

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.util.*;
import java.util.List;
import java.io.*;


public class Model {
    /** The observers that are watching this model for changes. */
    private List<Observer> observers;
    ArrayList<drawings> lines = new ArrayList<drawings>();

    /**
     * Create a new model.
     */
    public Model() {
        this.observers = new ArrayList();
    }

    /**
     * Add an observer to be notified when this model changes.
     */
    public void addObserver(Observer observer) {
        this.observers.add(observer);
    }

    /**
     * Remove an observer from this model.
     */
    public void removeObserver(Observer observer) {
        this.observers.remove(observer);
    }

    /**
     * Notify all observers that the model has changed.
     */
    public void notifyObservers() {
        for (Observer observer: this.observers) {
            observer.update(this);
        }
    }

    public void saveFile (View v, JFileChooser fileChooser)  {
        fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("Object file","ser"));
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
        int returnal = fileChooser.showSaveDialog(v);
        if (returnal == fileChooser.APPROVE_OPTION) {
            String path = fileChooser.getSelectedFile().getAbsolutePath();
            if (!path.endsWith(".ser")) {
                path += ".ser";
            }
            try {
                File file = new File(path);
                if (file.exists()) {
                    int i = JOptionPane.showConfirmDialog(v, "File already exists. Do you want to override it?");
                    if (i == JOptionPane.YES_OPTION) {
                        FileOutputStream fileOutputStream = new FileOutputStream(path);
                        ObjectOutputStream outputStream = new ObjectOutputStream(fileOutputStream);
                        outputStream.writeObject(lines);
                        outputStream.close();
                        fileOutputStream.close();
                    }
                    else return;
                }
            } catch (IOException i) {
                i.printStackTrace();
            }
        }
    }

    public void openFile (View v, JFileChooser fileChooser) {
        fileChooser = new JFileChooser();
        fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("Object file","ser"));
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
        int returnal = fileChooser.showOpenDialog(v);
        if (returnal == fileChooser.APPROVE_OPTION) {
            try {
                File loadIn = fileChooser.getSelectedFile();
                FileInputStream fileInputStream = new FileInputStream(loadIn);
                ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
                lines = (ArrayList<drawings>) objectInputStream.readObject();
                objectInputStream.close();
                fileInputStream.close();
                notifyObservers();
            }
            catch (IOException i) {
                i.printStackTrace();
            }
            catch (ClassNotFoundException c) {
                System.out.println("lines class not found");
                c.printStackTrace();
                return;
            }
        }
    }
}

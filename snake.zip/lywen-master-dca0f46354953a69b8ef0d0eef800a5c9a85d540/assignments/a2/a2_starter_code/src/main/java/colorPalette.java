import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class colorPalette extends JPanel {
    private View myView;

    public colorPalette (View v) {
        myView = v;
        //setPanel size
        setMaximumSize(new Dimension(120, 330));
        setMinimumSize(new Dimension(120, 330));

        //gridLayout
        GridLayout gl = new GridLayout (5,2,5,5);
        this.setLayout(gl);
        // add color button
        this.add(createColor(Color.RED));
        this.add(createColor(Color.ORANGE));
        this.add(createColor(Color.YELLOW));
        this.add(createColor(Color.GREEN));
        this.add(createColor(Color.CYAN));
        this.add(createColor(Color.BLUE));
        this.add(createColor(Color.MAGENTA));
        this.add(createColor(Color.PINK));
        this.add(createColor(Color.WHITE));
        this.add(createColor(Color.BLACK));

        //
    }

    private JButton createColor(Color c) {
        JButton button = new JButton();
        button.setBackground(c);
        button.setOpaque(true);
        button.setBorder(new LineBorder(Color.LIGHT_GRAY, 2));
        button.setMaximumSize(new Dimension(50, 50));
        button.setMinimumSize(new Dimension (50, 50));
        button.setBorder(new LineBorder(Color.lightGray));

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                myView.notifyColorChange(c);
            }
        });
        return button;
    }
}

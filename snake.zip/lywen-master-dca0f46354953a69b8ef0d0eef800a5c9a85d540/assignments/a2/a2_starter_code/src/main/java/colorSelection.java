import javax.swing.*;
import java.awt.*;

public class colorSelection extends JPanel {
    public int width = 110;
    public int height = 200;

    public colorSelection () {
        setMaximumSize(new Dimension(110, 170));
        setBackground(Color.WHITE);
        setOpaque(true);
    }

    public void changeColor (Color c) {
        this.setBackground(c);
        this.setOpaque(true);
    }


}

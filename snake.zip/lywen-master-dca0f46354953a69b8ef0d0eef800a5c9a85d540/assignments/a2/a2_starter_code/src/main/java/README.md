#ReadMe
The project implements a basic drawing palette with a color bar, <br>
a palette, a bottom tool bar. <br>

Due to time restriction, the resize is not completed, and the <br>
playback animation is not perfect<br>

The enhancement of this project is that the canvas will maintain<br>
its aspect ratio during resizing.
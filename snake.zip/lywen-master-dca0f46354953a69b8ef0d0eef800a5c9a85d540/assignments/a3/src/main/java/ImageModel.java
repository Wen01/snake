import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.awt.*;
import javax.imageio.*;
import java.net.*;


public class ImageModel implements java.io.Serializable {
    private String fileName;
    private String date;
    private int rate = 0;
    String imgPath;
    ImageCollectionModel cm;

    public ImageModel (File file) {
        try {
            imgPath = file.getAbsolutePath();
        }
        catch(Exception ie) {
            ie.printStackTrace();
        }
        Date nowdate = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
        date = dateFormat.format(nowdate);
        fileName = file.getName();
    }

    public String getImg () {
        return this.imgPath;
    }

    public String getDate() {
        return this.date;
    }

    public int getRate () {
        return this.rate;
    }

    public String getName () {
        return this.fileName;
    }

    public void rateChange(int r) {
        rate = r;
        System.out.println(rate);
        cm.hasChange();
    }
}

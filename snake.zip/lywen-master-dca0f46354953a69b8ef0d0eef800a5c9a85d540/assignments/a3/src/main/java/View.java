
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.util.*;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class View extends JFrame implements Observer {

    private Model model;
    private ImageCollectionModel cm;
    Toolbar toolbar;
    ImageCollectionView imgsView;

    /**
     * Create a new View.
     */
    public View(Model model) {
        // Set up the window.
        this.setTitle("Fotag!");
        this.setMinimumSize(new Dimension(600, 450));
        this.setPreferredSize(new Dimension(800, 600));
        this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        View v = this;
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                if (cm.ImageCollection.size() == 0) {
                    System.exit(0);
                }
                else {
                    int j = JOptionPane.showConfirmDialog(v, "Do you want to save all images?");
                    if (j == JOptionPane.YES_OPTION) {
                        cm.saveData();
                        //dispose();
                        toolbar.fb.clear();
                        System.exit(0);
                    }
                    else {
                        File file = new File("save.ser");
                        file.delete();
                        System.exit(0);
                    }
                }
            }
        });

        // Hook up this observer so that it will be notified when the model
        // changes.
        this.model = model;
        model.addObserver(this);
        cm = new ImageCollectionModel();
        model.setImgModel(cm);

        imgsView = new ImageCollectionView(cm);
        cm.addObserver(imgsView);
        //imgsView.setSize(new Dimension (800, 550));

        toolbar = new Toolbar(this, imgsView);

        cm.loadSaved();
        cm.fb = toolbar.fb;
        manageLayout();

    }

    /**
     * Update with data from the model.
     */
    public void update(Object observable) {
        // XXX Fill this in with the logic for updating the view when the model
        // changes.
        System.out.println("Model changed!");
    }

    public void notifyUpload() {
        View v = this;
        model.upLoad(v);
    }

    public void notifyGrid(){
        imgsView.grid = true;
        imgsView.update(cm);
    }

    public void notifyList() {
        imgsView.grid = false;
        imgsView.update(cm);
    }

    public void clearFilter () {
        imgsView.update(cm);
    }

    private void manageLayout () {
        JScrollPane container = new JScrollPane();
        container.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(0, 0));
        panel.setBorder(new EmptyBorder(5,5,5,5));
        panel.add(toolbar, BorderLayout.NORTH);
        panel.add(container, BorderLayout.CENTER);
        container.setViewportView(imgsView);
        this.getContentPane().add(panel);
        this.pack();
        //this.getContentPane().setBackground(new Color (240, 248, 255));
        resizeVersion();
        setVisible(true);
    }
    public void resizeVersion () {
        this.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                super.componentResized(e);
                int minWidth = 800;
                int minHeight = 600;
                Rectangle component = e.getComponent().getBounds();
                //cv.clearCanvas();
                e.getComponent().setBounds(component.x, component.y, component.width, component.width*minHeight/minWidth);
                //cv.resizeManage();

                if (component.width >= 800) {
                    imgsView.colNum = 3;
                    imgsView.update(cm);
                }
                if (component.width < 800 && component.width >= 600) {
                    imgsView.colNum = 2;
                    imgsView.update(cm);
                }
            }
        });
    }
}

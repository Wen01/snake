
import javax.swing.*;
import java.util.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;

public class Model {
    /** The observers that are watching this model for changes. */
    private List<Observer> observers;
    public ImageCollectionModel imgInfoCollect;
    public JFileChooser fileChooser;


    /**
     * Create a new model.
     */
    public Model() {

        this.observers = new ArrayList();
        //imgInfoCollect = new ImageCollectionModel();
    }

    /**
     * Add an observer to be notified when this model changes.
     */
    public void addObserver(Observer observer) {
        this.observers.add(observer);
    }

    public void setImgModel (ImageCollectionModel icm) {imgInfoCollect = icm;}

    /**
     * Remove an observer from this model.
     */
    public void removeObserver(Observer observer) {
        this.observers.remove(observer);
    }

    /**
     * Notify all observers that the model has changed.
     */
    public void notifyObservers() {
        for (Observer observer: this.observers) {
            observer.update(this);
        }
    }

    public void upLoad(View v) {
        int sameImg = 0;
        fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new FileNameExtensionFilter("image","jpeg", "gif", "jpg", "png"));
        fileChooser.setMultiSelectionEnabled(true);
        fileChooser.setCurrentDirectory(new File(System.getProperty("user.dir")));
        int returnal = fileChooser.showOpenDialog(v);
        if (returnal == fileChooser.APPROVE_OPTION) {
            File[] files = fileChooser.getSelectedFiles();
            for (File file : files) {
                ArrayList<ImageModel> imgs = imgInfoCollect.ImageCollection;
                for (int i = 0; i < imgs.size(); i++) {
                    if (imgs.get(i).getName().equals(file.getName())) {
                        sameImg = 1;
                        int k = JOptionPane.showConfirmDialog(v,"File already exists, do you want to override it?");
                        if (k == JOptionPane.YES_OPTION) {
                            imgInfoCollect.override(file);
                        }
                        break;
                    }
                }
                if (sameImg == 1) {
                    sameImg = 0;
                    continue;
                }
                imgInfoCollect.upLoad(file);
            }
        }
    }
}

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.io.IOException;
import javax.imageio.*;

public class rate extends JPanel {
    private ImageModel myModel;
    public ArrayList<rateButton> myRate = new ArrayList<>();
    private ImageIcon star, blackStar;

    public rate (ImageModel m) {
        myModel = m;
        setBackground(new Color(0xFEF5FD));
        for (int i = 0; i < 5; i++) {
            rateButton rb = new rateButton(i+1);
            rb.addMouseListener(new rateControl());
            myRate.add(rb);
            add(rb);
        }
        setLayout(new FlowLayout(FlowLayout.LEFT));
    }

    private class rateControl extends MouseAdapter {
        public void mouseClicked (MouseEvent evt) {
            rateButton b = (rateButton) evt.getComponent();
            myModel.rateChange(b.getRate());
            for (int i = 0; i < b.getRate(); i++) {
                myRate.get(i).setFilled();
            }
            if (b.getRate() < 5) {
                for (int i = b.getRate(); i < 5; i++) {
                    myRate.get(i).setUnfilled();
                }
            }
        }
    }

}

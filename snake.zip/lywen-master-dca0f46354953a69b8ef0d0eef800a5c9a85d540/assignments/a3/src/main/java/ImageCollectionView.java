import javax.swing.*;
import java.awt.*;
import java.util.*;


public class ImageCollectionView extends JPanel implements Observer {
    ImageCollectionModel collectionModel;
    ArrayList<ImageView> collectView;
    boolean grid = true;
    int colNum = 3;

    public ImageCollectionView (ImageCollectionModel cm) {
        super();
        collectionModel = cm;
        collectView = new ArrayList<>();
        setLayout(new GridLayout(3,0));
        //setPreferredSize(new Dimension (800, 550));
        setBackground(new Color (254, 245, 253));
        setOpaque(true);
    }

    public void update (Object observerable) {
        if (grid) setLayout(new GridLayout(0,colNum));
        else {
            setLayout(new GridLayout(0, 1));
        }

        while (collectionModel.ImageCollection.size() > collectView.size()) {
            int size = collectView.size();
            ImageModel newimg = collectionModel.ImageCollection.get(size);
            ImageView newView = new ImageView(newimg);
            collectView.add(newView);
        }

        for (int i = 0; i < collectView.size(); i++) {
            if (grid) {
                collectView.get(i).manageGridLayout();
            }
            else collectView.get(i).manageListLayout();
            add(collectView.get(i));
        }

        revalidate();
        repaint();
    }

    public void filterDisplay (int filter) {
        removeAll();
        for (int i = 0; i < collectView.size(); i++) {
            if (collectView.get(i).rating() >= filter) {
                add(collectView.get(i));
            }
        }

        revalidate();
        repaint();
    }
}

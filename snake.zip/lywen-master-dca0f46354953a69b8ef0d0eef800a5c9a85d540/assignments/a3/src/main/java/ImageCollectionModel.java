import javax.swing.*;
import java.util.*;
import java.io.*;
import java.awt.*;
import java.beans.*;

public class ImageCollectionModel implements java.io.Serializable {
    ArrayList<ImageModel> ImageCollection;
    private Observer observe;
    filterButton fb;

    public ImageCollectionModel () {
        ImageCollection = new ArrayList<> ();
    }

    public void upLoad (File file) {
        ImageModel newImage = new ImageModel(file);
        ImageCollection.add(newImage);
        newImage.cm = this;
        observe.update(this);
    }

    public void override (File file) {
        for (int i = 0; i < ImageCollection.size(); i++) {
            if (ImageCollection.get(i).getName() == file.getName()) {
                ImageModel override = new ImageModel(file);
                ImageCollection.set(i, override);
                override.cm = this;
            }
        }
        observe.update(this);
    }

    public ImageModel getNewImg () {
        System.out.println("Get new img ");
        return ImageCollection.get(ImageCollection.size() - 1);
    }

    public void addObserver (ImageCollectionView o) {
        observe = o;
    }

    public void saveData() {
        try {
            ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("save.ser"));
            outputStream.writeObject(ImageCollection);
            outputStream.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadSaved() {
        try {
            ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream("save.ser"));
            ImageCollection = (ArrayList<ImageModel>) inputStream.readObject();
            inputStream.close();
            observe.update(this);
        }
        catch (Exception e) {
            System.out.print("No such file.");
        }
    }

    public void hasChange () {
        //System.out.println (fb.data);
        fb.clear();
        observe.update(this);
    }
}

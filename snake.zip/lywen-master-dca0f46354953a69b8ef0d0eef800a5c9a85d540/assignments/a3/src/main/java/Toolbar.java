import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.*;
import javax.imageio.*;

public class Toolbar extends JPanel {
    View myView;
    ImageCollectionView icv;
    private JButton Load;
    private JButton grid;
    private JButton List;
    private JLabel filter;
    filterButton fb;
    private JButton clear;
    JLabel Fotag = new JLabel("Fotag!");

    public Toolbar (View v, ImageCollectionView icv) {
        myView = v;
        this.icv = icv;
        this.setSize(new Dimension(800, 50));
        this.setLayout (new GridBagLayout());
        this.setBackground(new Color(237, 180, 189));
        this.setOpaque(true);
        try {
            gridView();
            listView();
            upload();
        }
        catch(IOException ie) {
            ie.printStackTrace();
        }
        Fotag.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
        Box b = Box.createHorizontalBox();
        b.add(Box.createHorizontalStrut(5));
        b.add(grid);
        b.add(Box.createHorizontalStrut(5));
        b.add(List);
        b.add(Box.createHorizontalStrut(5));
        b.add(Load);
        b.add(Box.createHorizontalStrut(30));
        b.add(Fotag);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 0.5;
        c.weighty = 1.0;
        c.gridwidth = 1;
        c.fill = GridBagConstraints.BOTH;
        this.add(b, c);

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 1.0;
        c.gridwidth = 0;

        JPanel panel = new JPanel();
        panel.setSize(new Dimension (700, 50));
        panel.setBackground(new Color(237, 180, 189));
        panel.setOpaque(true);
        panel.setLayout(new FlowLayout(FlowLayout.RIGHT));

        filter = new JLabel("Filter by: ");
        fb = new filterButton(icv);
        clear = new JButton("Clear");
        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                fb.clear();
                myView.clearFilter();
            }
        });
        panel.add(filter);
        panel.add(fb);
        panel.add(clear);
        this.add(panel,c);


    }

    private void gridView () throws IOException {
        grid = new JButton ();
        grid.setSize (new Dimension (30, 30));
        Image img = ImageIO.read(this.getClass().getResource("gridView.png"));
        Image dimg = img.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        grid.setIcon(new ImageIcon(dimg));
        grid.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                myView.notifyGrid();
            }
        });
    }

    private void listView () throws IOException {
        List = new JButton ();
        List.setSize (new Dimension (30, 30));
        Image img = ImageIO.read(this.getClass().getResource("listView.png"));
        Image dimg = img.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        List.setIcon (new ImageIcon(dimg));
        List.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                myView.notifyList();
            }
        });
    }

    private void upload () throws IOException {
        Load = new JButton();
        //Load.setBackground(Color.BLACK);
        //Load.setOpaque(true);
        Load.setSize (new Dimension (30, 30));
        Image img = ImageIO.read(this.getClass().getResource("loadImg.png"));
        Image dimg = img.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        Load.setIcon (new ImageIcon(dimg));
        Load.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                myView.notifyUpload();
            }
        });
    }
}

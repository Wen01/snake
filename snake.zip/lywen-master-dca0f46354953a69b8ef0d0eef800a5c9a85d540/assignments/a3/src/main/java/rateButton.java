import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class rateButton extends JButton {
    private int rate;
    private ImageIcon star, blackStar;
    //boolean filled;

    public rateButton (int rate) {
        //filled = false;
        this.rate = rate;
        try {
            Image img = ImageIO.read(this.getClass().getResource("star.png"));
            Image dimg = img.getScaledInstance(20, 20, Image.SCALE_SMOOTH);
            star = new ImageIcon(dimg);

            Image img2 = ImageIO.read(this.getClass().getResource("blackstar.png"));
            Image dimg2 = img2.getScaledInstance(20, 20, Image.SCALE_SMOOTH);
            blackStar = new ImageIcon(dimg2);
        }
        catch (IOException ie) {
            ie.printStackTrace();
        }

        setIcon(star);
        setOpaque(false);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setPreferredSize(new Dimension(20, 20));
    }

    public void setFilled () {
        setIcon (blackStar);
        //filled = true;
    }

    public void setUnfilled () {
        setIcon (star);
        //filled = false;
    }

    public int getRate () {
        return rate;
    }
}



import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.*;

public class ImageView extends JPanel {
    private ImageModel myModel;
    JLabel imgField;
    JLabel nameField;
    JLabel dateField;
    rate rateButton;
    //JButton clear;

    public ImageView (ImageModel im) {
        myModel = im;
        manageImg();

        // set file name
        nameField = new JLabel(myModel.getName());

        // set date
        dateField = new JLabel(myModel.getDate());
        dateField.addMouseListener(new clearRate());

        rateButton = new rate(myModel);

        //clear = new JButton("clear");

        //manageLayout();
    }

    private void manageImg () {
        System.out.println("photo uploaded ");
        imgField = new JLabel();
        ImageIcon icon = new ImageIcon(myModel.getImg());
        Image img = icon.getImage();
        Image dimg = img.getScaledInstance(200, 150, Image.SCALE_DEFAULT);
        imgField.setIcon(new ImageIcon(dimg));

        imgField.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                JFrame enlarge = new JFrame(myModel.getName());
                enlarge.setMaximumSize(new Dimension (800, 600));
                enlarge.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

                JLabel content = new JLabel();
                ImageIcon icon = new ImageIcon(myModel.getImg());
                Image img = icon.getImage();
                Image dimg = img.getScaledInstance(800, 600, Image.SCALE_DEFAULT);
                content.setIcon(new ImageIcon(dimg));

                enlarge.setContentPane(content);
                enlarge.pack();
                enlarge.setVisible(true);
            }
        });
    }

    public void manageGridLayout () {
        //setBackground(Color.WHITE);
        //setOpaque(false);
        setPreferredSize(new Dimension(250, 250));
        //setBorder(new LineBorder(new Color (0xF0A7AD), 2));
        setBackground(new Color (0xFEF5FD));
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.gridwidth = 3;
        c.gridheight = 1;
        c.gridx = 0;
        c.gridy = 0;
        add(imgField, c);
        c.gridy = 1;
        add(nameField, c);
        c.gridwidth = 1;
        c.gridy = 2;
        add(dateField, c);
        c.gridwidth = 2;
        c.gridx = 1;
        add(rateButton, c);
    }

    public void manageListLayout () {
        setPreferredSize(new Dimension(800, 250));
        //setBackground(Color.WHITE);
        //setOpaque(true);
        setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        setBackground(new Color(0xFEF5FD));
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0.3;
        c.gridwidth = 2;
        c.gridheight = 3;
        c.gridx = 0;
        c.gridy = 0;
        add(imgField, c);

        c.weightx = 1;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.gridx = 3;
        c.gridy = 0;
        add(nameField,c);

        c.gridy = 1;
        add(dateField, c);

        c.gridwidth = 2;
        c.gridy = 2;
        add(rateButton, c);
    }

    private class clearRate extends MouseAdapter {
        public void mouseClicked (MouseEvent evt) {
            myModel.rateChange(0);
            for (int i = 0; i < rateButton.myRate.size(); i ++) {
                rateButton.myRate.get(i).setUnfilled();
            }
        }
    }

    public int rating () {
        return myModel.getRate();
    }

}


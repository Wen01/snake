import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.*;

public class filterButton extends JPanel {
    ImageCollectionView allImgs;
    ArrayList<rateButton> filter;

    public filterButton (ImageCollectionView icv) {
        allImgs = icv;
        filter = new ArrayList<>(5);
        setBackground(new Color(237, 180, 189));
        setOpaque(true);
        for (int i = 0; i < 5; i++) {
            rateButton rb = new rateButton(i + 1);
            rb.addMouseListener(new rateControl());
            filter.add(rb);
            add(rb);
        }
    }

    private class rateControl extends MouseAdapter {
        public void mouseClicked (MouseEvent evt) {
            rateButton b = (rateButton) evt.getComponent();
            int k = b.getRate();
            allImgs.filterDisplay (k);
            for (int i = 0; i < b.getRate(); i++) {
                filter.get(i).setFilled();
            }
            if (b.getRate() < 5) {
                for (int i = b.getRate(); i < 5; i++) {
                    filter.get(i).setUnfilled();
                }
            }
        }
    }

    public void clear () {
        for (int i = 0; i < 5; i++) {
            filter.get(i).setUnfilled();
        }
    }
}

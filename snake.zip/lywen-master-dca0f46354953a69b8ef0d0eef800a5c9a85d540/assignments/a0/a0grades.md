# CS349 A0
Student: lywen
Marker: Nikhita Joshi

Total: 1 / 1 (100.00%)

[1/1] Completed A0 with the correct version of Java installed.

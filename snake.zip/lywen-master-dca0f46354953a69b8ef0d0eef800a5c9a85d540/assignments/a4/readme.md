The .apk file is under app/src directory, and if the prog fails to compile <br>
with .apk, please try to run with android studio, thanks so much <br>

When testing with Android Studio, sometimes a dialog will be shown, <br>
telling that "System UI is not responding", but if press "Wait", the prog <br>
will still run properly afterwards. If you also find this problem while testing, <br>
please just press wait, or exit and rebuild my program. <br>


And because of the time limit, I didn't finish the enhancement<br>
therefore, the search button under menu bar actually is useless. <br>

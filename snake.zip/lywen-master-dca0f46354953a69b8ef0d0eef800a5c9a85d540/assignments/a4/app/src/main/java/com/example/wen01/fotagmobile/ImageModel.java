package com.example.wen01.fotagmobile;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

class ImageModel {
    private ImageCollectionModel parent;
    private int rate;
    private Bitmap img;
    boolean fullScreen;

    public ImageModel(Bitmap i, int r, ImageCollectionModel p) {
        img = i;
        rate = r;
        parent = p;
        System.out.println("Image meta data set");
        fullScreen = false;
    }

    public int getRate () {
        return rate;
    }

    public Bitmap getImg () {
        return img;
    }

    public void changeRate (int r) {
        rate = r;
        parent.notifyRateChange();
    }

}

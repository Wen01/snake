package com.example.wen01.fotagmobile;

import java.util.ArrayList;
import android.graphics.Bitmap;
import android.util.*;

class ImageCollectionModel {
    private ArrayList<ImageModel> imagesData;
    ArrayList<ImageModel> filteredImg;
    private ImageCollectionView mainview;
    private int filterNum;

    public ImageCollectionModel () {
        Log.d(String.valueOf(R.string.DEBUG_MVC_ID), "ImageCollection created");
        imagesData = new ArrayList<>();
        filteredImg = new ArrayList<>();
        filterNum = 0;
    }

    public void clear () {
        imagesData.clear();
        Log.d(String.valueOf(R.string.DEBUG_MVC_ID),"Image cleared");
        changeView();
    }

    public void addImage(Bitmap b) {
        ImageModel newImage = new ImageModel(b, 0, this);
        imagesData.add(newImage);
        filteredImg.add(newImage);
    }

    public void filterImgs (int rate) {
        filterNum = rate;
        filteredImg.clear();
        //changeView();
        for (int i = 0; i < imagesData.size(); i++) {
            if (imagesData.get(i).getRate() >= filterNum) {
                filteredImg.add(imagesData.get(i));
            }
        }
        changeView();
    }

    public int getSavedNum () {
        return imagesData.size();
    }

    public ArrayList<ImageModel> getImagesData () {
        return filteredImg;
    }

    public int getImgNum () {
        return filteredImg.size();
    }

    public Bitmap getImage(int pos) {
        return filteredImg.get(pos).getImg();
    }

    public void addView (ImageCollectionView v) {
        mainview = v;
    }

    public void changeView () {
        mainview.notifyDataSetChanged();
    }

    public void notifyRateChange () {
        if (filterNum > 0 ) {
            filteredImg.clear();
            for (int i = 0; i < imagesData.size(); i++) {
                if (imagesData.get(i).getRate() >= filterNum) {
                    filteredImg.add(imagesData.get(i));
                }
            }
            changeView();
        }
    }
}

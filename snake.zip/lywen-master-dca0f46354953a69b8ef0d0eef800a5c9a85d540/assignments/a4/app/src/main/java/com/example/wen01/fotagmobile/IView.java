package com.example.wen01.fotagmobile;

interface IView {

    public void updateView ();
}

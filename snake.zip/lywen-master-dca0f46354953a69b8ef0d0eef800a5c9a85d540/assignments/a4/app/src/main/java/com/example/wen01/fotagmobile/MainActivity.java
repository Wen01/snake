package com.example.wen01.fotagmobile;

import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import android.support.v7.widget.Toolbar;


public class MainActivity extends AppCompatActivity {
    private ImageCollectionModel images_model;
    private ImageCollectionView images_view;
    private Toolbar tool;
    private RatingBar filter;
    GridView gridView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainactivity);

        images_model = new ImageCollectionModel();
        images_view = new ImageCollectionView(this, images_model);
        images_model.addView(images_view);
        tool = (Toolbar) findViewById(R.id.toolbar);
        filter = (RatingBar) findViewById(R.id.filter);
        filter.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                if (b) {
                    images_model.filterImgs((int) v);
                }
            }
        });
        setSupportActionBar(tool);

        gridView = (GridView) findViewById(R.id.mainpanel);
        gridView.setAdapter(images_view);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                Toast.makeText(MainActivity.this, "" + position,
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onConfigurationChanged (Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        setContentView(R.layout.mainactivity);
        tool = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(tool);

        gridView = (GridView) findViewById(R.id.mainpanel);
        gridView.invalidateViews();
        gridView.setAdapter(images_view);
        //System.out.println(images_model.getImgNum());
        images_view.notifyDataSetChanged();
    }

    @Override
    protected void onSaveInstanceState (Bundle outBundle) {
        super.onSaveInstanceState(outBundle);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menubar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu (Menu menu) {
        if (images_model.getSavedNum() > 0) {
            menu.getItem(1).setEnabled(false);
        }
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle interaction based on item selection
        switch (item.getItemId())
        {
            case R.id.clear:
                // Create Intent to launch second activity
                images_model.clear();  // don't place this on the stack, can't use back button
                filter.setRating(0F);
                return true;

            case R.id.load:
                Bitmap b = BitmapFactory.decodeResource(getResources(), R.drawable.test1);
                images_model.addImage(b);
                b = BitmapFactory.decodeResource(getResources(), R.drawable.test2);
                images_model.addImage(b);
                b = BitmapFactory.decodeResource(getResources(), R.drawable.test3);
                images_model.addImage(b);
                b = BitmapFactory.decodeResource(getResources(), R.drawable.test4);
                images_model.addImage(b);
                b = BitmapFactory.decodeResource(getResources(), R.drawable.test5);
                images_model.addImage(b);
                b = BitmapFactory.decodeResource(getResources(), R.drawable.test6);
                images_model.addImage(b);
                b = BitmapFactory.decodeResource(getResources(), R.drawable.test7);
                images_model.addImage(b);
                b = BitmapFactory.decodeResource(getResources(), R.drawable.test8);
                images_model.addImage(b);
                b = BitmapFactory.decodeResource(getResources(), R.drawable.test9);
                images_model.addImage(b);
                b = BitmapFactory.decodeResource(getResources(), R.drawable.test10);
                images_model.addImage(b);
                System.out.println("Images finish loading.");
                images_model.changeView();
                return true;

        }
        return super.onOptionsItemSelected(item);
    }


}

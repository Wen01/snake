package com.example.wen01.fotagmobile;

import android.graphics.*;
import android.view.View.*;
import android.view.*;
import android.widget.BaseAdapter;
import android.widget.*;
import android.app.*;
import android.util.*;
import android.content.Context;

class ImageCollectionView extends BaseAdapter{
    private Context mContext;
    private ImageCollectionModel model;
    DisplayMetrics dm;

    public ImageCollectionView (Context c, ImageCollectionModel m) {
        mContext = c;
        model = m;
        dm = c.getResources().getDisplayMetrics();
    }

    public int getCount() {
        return model.getImgNum();
    }

    public Object getItem(int position) {
        return null;
    }

    public long getItemId(int position) {
        return 0;
    }


    @Override
    public View getView (final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(mContext);
        ViewHolder holder = null;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.imagelayout, parent,  false);
            holder = new ViewHolder();
            holder.imageField = (ImageView) convertView.findViewById(R.id.imagefield);
            holder.rating = (RatingBar) convertView.findViewById(R.id.rating);
            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }
        final Bitmap img = model.getImage(position);
        holder.imageField.setImageBitmap(img);
        holder.imageField.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog=new Dialog(mContext,android.R.style.Theme_Black_NoTitleBar_Fullscreen) {
                    @Override
                    public boolean onTouchEvent(MotionEvent event) {
                        this.dismiss();
                        return true;
                    }
                };
                dialog.setContentView(R.layout.fullscreen);
                ImageView full = (ImageView) dialog.findViewById(R.id.fullimage);
                full.setImageBitmap(img);
                dialog.show();
            }
        });
        holder.rating.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                if (b) {
                    model.filteredImg.get(position).changeRate((int) v);
                }
            }
        });
        holder.rating.setRating(model.filteredImg.get(position).getRate());
        //System.out.println ("Position:" + position + "Rate:" + model.filteredImg.get(position).getRate());
        return convertView;
    }

    static class ViewHolder{
        ImageView imageField;
        RatingBar rating;
    }
}

# Snake Rules and Controls

To play the game, <br>
Press S to start the game. <br>
Press W, A, S, D to control the snake movements. <br>
Press R to restart, P to pause, C to continue. <br> <br>
Each time the snake eats a fruit, player will earn 5 scores. <br><br>
The white boxes in the center and around the boundary are obstacles, 
Players are not allowed to touch it, otherwise they will lose the game.<br><br>
The player will also lose the game if the snake touches its own body during the movement.<br>
<br>
The snake can be wrapped around to the other side of the screen, if it runs out of boundary.
 

# CS349 A1
Student: lywen
Marker: Jay Henderson


Total: 100 / 100 (100.00%)

Code: 
(CO: won’t compile, CR: crashes, FR: UI freezes/unresponsive, NS: not submitted)


Notes:   

# A1 Marking Scheme (draft)

You are to implement a snake game of your own design with C++ and Xlib, running on an XServer (Windows XMing, macOS XQuartz, or Linux). You should compile and test with g++ 4.9.4 or later (since we will test on the student environment using that version). You are not allowed to use any other third-party libraries.

* -50% if you implement in an unsupported version of g++ or xlib
* -100% if you implement in a completely different programming language

## Basics (10%)

1. [5/5] Code compiles and runs (5%).

2. [5/5] Include a README text file with a description of the game, the controls, the enhancements, the development environment, and anything else that TAs should know when grading.

## Technical requirements (40%)

3. [20/20] The game must accept two command-line parameters: (1) "frame-rate", which controls how often the screen is repainted, and (2) speed of the snake, describing how fast the snake moves in the game. Parameters must be of the format ./snake 30 5, where 30 defines the framerate and 5 defines the speed. If not specified on the command line, the program should run at a framerate of 30 and speed of 5 (i.e. these are the defaults).

4. [20/20] The game must play smoothly with proper collision detection in the range of 25 to 60 FPS (while supporting a range of 1-100 FPS for testing).

## Gameplay requirements (40%)

5. [4/4] The game should open with a splash screen that includes your name, userid, and a description of how to play the game (including a description of which keys to use).

6. [8/8] The game screen displays a snake (chain of blocks) always in motion and a fruit (block) at a fixed point on the screen. The snake can move 1 pixel at a time, or one "block" at a time (where a block is a fixed number of pixels), scaled to the speed (parameter). 

7. [4/4] The game must use the arrow keys (and/or WASD) to control the snake's movements. Specify in the README which controls to use.

8. [8/8] The objective of the snake is to eat the target fruit, which makes it grow in length. As the snake eats the fruit, it disappears, and another fruit appears at a random location.

9. [4/4] The snake can die by eating itself (when it collides with itself) or by hitting the edge of the screen or any other obstacles. When the snake dies, a game-end screen should appear (below).

10. [4/4] The game should keep track of a score that updates over the course of the game. 

11. [4/4] The game should have the ability to play, pause, and restart the level.

12. [4/4] When the game ends, there should be a game-over screen, providing the player with the ability to restart the game, or quit.

13. [10/10] Enhancements: Up to 10% awarded from this list

* Creative level design. A classic level is a bounded square region with no obstacles inside. You can enhance this by adding obstacles that the snake must avoid and gaps on the border that lets the snake wrap around to other side of the screen.(10 marks)

